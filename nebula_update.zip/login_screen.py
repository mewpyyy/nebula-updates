import tkinter as tk
from tkinter import font as tkfont

from config import (
    validate_user_remote, load_session, save_session, clear_session,
    resource_path,
)


class LoginScreen(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Nebula — Login")
        self.resizable(False, False)
        self.configure(bg="#0d0010")
        self._success     = False
        self._logged_user = None

        try:
            self.iconbitmap(resource_path("nebula.ico"))
        except Exception:
            pass

        self.update_idletasks()

        font_title = tkfont.Font(family="Segoe Script", size=18, weight="bold")
        font_sub   = tkfont.Font(family="Segoe UI",     size=9)
        font_label = tkfont.Font(family="Segoe UI",     size=8,  weight="bold")
        font_entry = tkfont.Font(family="Segoe UI",     size=11)
        font_err   = tkfont.Font(family="Segoe UI",     size=8)
        font_btn   = tkfont.Font(family="Segoe UI",     size=10, weight="bold")
        font_check = tkfont.Font(family="Segoe UI",     size=9)

        wrap = tk.Frame(self, bg="#0d0010", padx=48, pady=40)
        wrap.pack()

        tk.Label(wrap, text="⬡ Nebula", font=font_title,
                 bg="#0d0010", fg="#c084fc").pack(pady=(0, 4))
        tk.Label(wrap, text="sign in to continue", font=font_sub,
                 bg="#0d0010", fg="#6b21a8").pack(pady=(0, 24))

        tk.Label(wrap, text="USERNAME", font=font_label,
                 bg="#0d0010", fg="#a855f7", anchor="w").pack(fill="x")
        self._user_var = tk.StringVar()
        self._user_entry = tk.Entry(
            wrap, textvariable=self._user_var,
            font=font_entry, bg="#1a0030", fg="#e9d5ff",
            insertbackground="#c084fc", relief="flat", bd=0,
            highlightthickness=1, highlightbackground="#4c1d95",
            highlightcolor="#a855f7")
        self._user_entry.pack(fill="x", ipady=8, pady=(4, 16))

        tk.Label(wrap, text="PASSWORD", font=font_label,
                 bg="#0d0010", fg="#a855f7", anchor="w").pack(fill="x")
        self._pass_var = tk.StringVar()
        self._pass_entry = tk.Entry(
            wrap, textvariable=self._pass_var,
            font=font_entry, bg="#1a0030", fg="#e9d5ff",
            insertbackground="#c084fc", relief="flat", bd=0, show="•",
            highlightthickness=1, highlightbackground="#4c1d95",
            highlightcolor="#a855f7")
        self._pass_entry.pack(fill="x", ipady=8, pady=(4, 12))

        self._remember_var = tk.BooleanVar(value=False)
        rem_frame = tk.Frame(wrap, bg="#0d0010")
        rem_frame.pack(fill="x", pady=(0, 16))
        tk.Checkbutton(
            rem_frame, text="Remember me",
            variable=self._remember_var,
            font=font_check, bg="#0d0010", fg="#a855f7",
            activebackground="#0d0010", activeforeground="#c084fc",
            selectcolor="#1a0030", cursor="hand2", bd=0,
            highlightthickness=0).pack(side="left")

        self._err_var = tk.StringVar()
        tk.Label(wrap, textvariable=self._err_var,
                 font=font_err, bg="#0d0010", fg="#f87171").pack(pady=(0, 12))

        btn = tk.Label(wrap, text="LOGIN", font=font_btn,
                       bg="#4c1d95", fg="#e9d5ff", padx=32, pady=10,
                       cursor="hand2", relief="flat")
        btn.pack()
        btn.bind("<Button-1>", lambda e: self._attempt())
        self._pass_entry.bind("<Return>", lambda e: self._attempt())
        self._user_entry.bind("<Return>", lambda e: self._pass_entry.focus())

        self.update_idletasks()
        w, h = self.winfo_width(), self.winfo_height()
        x = (self.winfo_screenwidth()  - w) // 2
        y = (self.winfo_screenheight() - h) // 2
        self.geometry(f"+{x}+{y}")

        session = load_session()
        if session:
            self._user_var.set(session["user"])
            self._pass_var.set(session["pw"])
            self._remember_var.set(True)
            self._pass_entry.focus()
        else:
            self._user_entry.focus()

    def _attempt(self):
        user = self._user_var.get().strip()
        pw   = self._pass_var.get()
        if not user or not pw:
            self._err_var.set("please enter username and password")
            return
        self._err_var.set("checking...")
        self.update()
        if validate_user_remote(user, pw):
            if self._remember_var.get():
                save_session(user, pw)
            else:
                clear_session()
            self._success     = True
            self._logged_user = user
            self.destroy()
        else:
            self._err_var.set("incorrect username or password")
            self._pass_var.set("")
            self._pass_entry.focus()
