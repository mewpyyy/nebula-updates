import os
import json

# ── Version & URLs ────────────────────────────────────────────────────────────
CURRENT_VERSION    = "1.9.1"
UPDATE_VERSION_URL = "https://mewpyyy.github.io/nebula-updates/version.json"
UPDATE_ZIP_URL     = "https://mewpyyy.github.io/nebula-updates/nebula_update.zip"
SCRIPTS_JSON_URL   = "https://mewpyyy.github.io/nebula-updates/scripts.json"
PATCH_NOTES_URL    = "https://mewpyyy.github.io/nebula-updates/patch_notes.json"

# ── Users ─────────────────────────────────────────────────────────────────────
USERS = {
    "Physica":        "PhysiaAdmin1",
    "KukuTheGriefer": "Kuku6767",
    "Arukii":         "Outmined",
    "Jcash":          "Goober67",
    "Myrak":          "MK900!",
    "Physica5":       "Physica5",
    "Physica6":       "Physica6",
    "Physica7":       "Physica7",
    "Physica8":       "Physica8",
}

# ── Preset themes ─────────────────────────────────────────────────────────────
PRESET_THEMES = {
    "Cyber (Default)": {
        "bg": "#0d0f14", "card_bg": "#13161e", "border": "#1e2230",
        "accent": "#00e5ff", "accent2": "#ff4b6e", "text": "#e8eaf0",
        "subtext": "#5a6180", "running": "#00e5a0", "stopped": "#3a3f55",
        "tog_on": "#00e5ff", "tog_off": "#2a2f42", "tog_mid": "#0088aa",
    },
    "Midnight Purple": {
        "bg": "#0e0b16", "card_bg": "#1a1528", "border": "#2d2145",
        "accent": "#c77dff", "accent2": "#ff6b9d", "text": "#e8e0f0",
        "subtext": "#6b5f80", "running": "#a0f0c0", "stopped": "#3d3050",
        "tog_on": "#c77dff", "tog_off": "#2d2145", "tog_mid": "#7a40cc",
    },
    "Forest": {
        "bg": "#0b120e", "card_bg": "#111a14", "border": "#1e3024",
        "accent": "#4ade80", "accent2": "#fbbf24", "text": "#e0f0e8",
        "subtext": "#4a7060", "running": "#4ade80", "stopped": "#2a4030",
        "tog_on": "#4ade80", "tog_off": "#1e3024", "tog_mid": "#2a8048",
    },
    "Sunset": {
        "bg": "#12080a", "card_bg": "#1e0e12", "border": "#3a1820",
        "accent": "#ff6b35", "accent2": "#ff4b6e", "text": "#f0e0e4",
        "subtext": "#7a4050", "running": "#ffd166", "stopped": "#3a1820",
        "tog_on": "#ff6b35", "tog_off": "#3a1820", "tog_mid": "#aa4422",
    },
    "Ice": {
        "bg": "#080e14", "card_bg": "#0e1620", "border": "#1a2a3a",
        "accent": "#7dd3fc", "accent2": "#38bdf8", "text": "#e0eef8",
        "subtext": "#4a6880", "running": "#86efac", "stopped": "#1a2a3a",
        "tog_on": "#7dd3fc", "tog_off": "#1a2a3a", "tog_mid": "#2a6888",
    },
    "Light Mode": {
        "bg": "#f0f2f5", "card_bg": "#ffffff", "border": "#dde1e8",
        "accent": "#2563eb", "accent2": "#e11d48", "text": "#1e2030",
        "subtext": "#8090a8", "running": "#16a34a", "stopped": "#b0bac8",
        "tog_on": "#2563eb", "tog_off": "#c8d0dc", "tog_mid": "#6090c8",
    },
    "Rose Gold": {
        "bg": "#120a0e", "card_bg": "#1e1016", "border": "#3a1e28",
        "accent": "#f4a8c0", "accent2": "#f97316", "text": "#f0e4ea",
        "subtext": "#80505e", "running": "#86efac", "stopped": "#3a1e28",
        "tog_on": "#f4a8c0", "tog_off": "#3a1e28", "tog_mid": "#b06070",
    },
    "Neon Green": {
        "bg": "#040d06", "card_bg": "#081208", "border": "#0f2410",
        "accent": "#39ff14", "accent2": "#ff4b6e", "text": "#d4f5d8",
        "subtext": "#386040", "running": "#39ff14", "stopped": "#0f2410",
        "tog_on": "#39ff14", "tog_off": "#0f2410", "tog_mid": "#1a8820",
    },
    "Ocean Deep": {
        "bg": "#030d18", "card_bg": "#071626", "border": "#0d2840",
        "accent": "#0ea5e9", "accent2": "#f59e0b", "text": "#d0eaf8",
        "subtext": "#2c6080", "running": "#34d399", "stopped": "#0d2840",
        "tog_on": "#0ea5e9", "tog_off": "#0d2840", "tog_mid": "#0660a0",
    },
    "Volcanic": {
        "bg": "#100804", "card_bg": "#1c100a", "border": "#362010",
        "accent": "#fb923c", "accent2": "#f43f5e", "text": "#f0ddd0",
        "subtext": "#805040", "running": "#fbbf24", "stopped": "#362010",
        "tog_on": "#fb923c", "tog_off": "#362010", "tog_mid": "#a04010",
    },
    "Arctic": {
        "bg": "#f4f8fb", "card_bg": "#ffffff", "border": "#c8dce8",
        "accent": "#0284c7", "accent2": "#dc2626", "text": "#1a2a38",
        "subtext": "#6890a8", "running": "#059669", "stopped": "#a8c0d0",
        "tog_on": "#0284c7", "tog_off": "#c8dce8", "tog_mid": "#4a90c0",
    },
    "Dracula": {
        "bg": "#282a36", "card_bg": "#313344", "border": "#44475a",
        "accent": "#bd93f9", "accent2": "#ff5555", "text": "#f8f8f2",
        "subtext": "#6272a4", "running": "#50fa7b", "stopped": "#44475a",
        "tog_on": "#bd93f9", "tog_off": "#44475a", "tog_mid": "#7050c0",
    },
    "Mocha": {
        "bg": "#1e1610", "card_bg": "#2a1e14", "border": "#4a3020",
        "accent": "#d4a96a", "accent2": "#e07060", "text": "#f0e0cc",
        "subtext": "#806050", "running": "#a8d080", "stopped": "#4a3020",
        "tog_on": "#d4a96a", "tog_off": "#4a3020", "tog_mid": "#906030",
    },
    "Bubblegum": {
        "bg": "#0e0812", "card_bg": "#180f1e", "border": "#32183c",
        "accent": "#f472b6", "accent2": "#a78bfa", "text": "#fce7f3",
        "subtext": "#804060", "running": "#86efac", "stopped": "#32183c",
        "tog_on": "#f472b6", "tog_off": "#32183c", "tog_mid": "#a03070",
    },
    "Stealth": {
        "bg": "#0a0a0a", "card_bg": "#111111", "border": "#222222",
        "accent": "#888888", "accent2": "#cc4444", "text": "#cccccc",
        "subtext": "#555555", "running": "#66aa66", "stopped": "#222222",
        "tog_on": "#888888", "tog_off": "#222222", "tog_mid": "#444444",
    },
    "Synthwave": {
        "bg": "#0d0221", "card_bg": "#130338", "border": "#2d0a5a",
        "accent": "#ff71ce", "accent2": "#01cdfe", "text": "#fffb96",
        "subtext": "#5a2080", "running": "#05ffa1", "stopped": "#2d0a5a",
        "tog_on": "#ff71ce", "tog_off": "#2d0a5a", "tog_mid": "#a01880",
    },
}

PATCH_NOTES = {
    "1.9.0": [
        "Version number now displayed next to the Nebula logo (e.g. Nebula v1.4.6)",
        "App now remembers your last selected server — no need to pick every time",
        "Added 'Change Server' button in the header to return to server selection",
        "Script cards now show a live run time counter while a script is active",
        "Update popup now includes patch notes so you can see what changed before updating",
    ]
}

# ── File paths ────────────────────────────────────────────────────────────────
_HOME = os.path.expanduser("~")
STATS_FILE    = os.path.join(_HOME, ".ahkmanager_stats.json")
FAVS_FILE     = os.path.join(_HOME, ".ahkmanager_favs.json")
THEME_FILE    = os.path.join(_HOME, ".ahkmanager_theme.json")
SESSION_FILE  = os.path.join(_HOME, ".ahkmanager_session.json")
SERVER_FILE   = os.path.join(_HOME, ".ahkmanager_server.json")
KEYBINDS_FILE = os.path.join(_HOME, ".ahkmanager_keybinds.json")

DEFAULT_KEYBINDS = {"start": "F6", "stop": "F10", "exit": "F12"}

# ── Persistence helpers ───────────────────────────────────────────────────────
def load_stats():
    try:
        with open(STATS_FILE, "r") as f:
            return json.load(f)
    except Exception:
        return {}

def save_stats(stats):
    try:
        with open(STATS_FILE, "w") as f:
            json.dump(stats, f, indent=2)
    except Exception:
        pass

def load_favs():
    try:
        with open(FAVS_FILE, "r") as f:
            return json.load(f)
    except Exception:
        return []

def save_favs(favs):
    try:
        with open(FAVS_FILE, "w") as f:
            json.dump(favs, f, indent=2)
    except Exception:
        pass

def load_theme():
    try:
        with open(THEME_FILE, "r") as f:
            return json.load(f)
    except Exception:
        return dict(PRESET_THEMES["Cyber (Default)"])

def save_theme(theme):
    try:
        with open(THEME_FILE, "w") as f:
            json.dump(theme, f, indent=2)
    except Exception:
        pass

def load_session():
    try:
        with open(SESSION_FILE, "r") as f:
            data = json.load(f)
        if data.get("remember") and data.get("user") and data.get("pw"):
            return data
    except Exception:
        pass
    return None

def save_session(user, pw):
    try:
        with open(SESSION_FILE, "w") as f:
            json.dump({"remember": True, "user": user, "pw": pw}, f)
    except Exception:
        pass

def clear_session():
    try:
        os.remove(SESSION_FILE)
    except Exception:
        pass

def load_last_server():
    try:
        with open(SERVER_FILE, "r") as f:
            return json.load(f).get("server")
    except Exception:
        return None

def save_last_server(server):
    try:
        with open(SERVER_FILE, "w") as f:
            json.dump({"server": server}, f)
    except Exception:
        pass

def load_keybinds():
    try:
        with open(KEYBINDS_FILE, "r") as f:
            data = json.load(f)
        for k in DEFAULT_KEYBINDS:
            if k not in data:
                data[k] = DEFAULT_KEYBINDS[k]
        return data
    except Exception:
        return dict(DEFAULT_KEYBINDS)

def save_keybinds(kb):
    try:
        with open(KEYBINDS_FILE, "w") as f:
            json.dump(kb, f, indent=2)
    except Exception:
        pass

# ── Auth helpers ──────────────────────────────────────────────────────────────
def fetch_remote_users():
    return dict(USERS), None

def push_remote_users(users, sha=None):
    return True, ""

def validate_user_remote(username, password):
    return USERS.get(username) == password

# ── AHK finder ────────────────────────────────────────────────────────────────
import shutil

def find_autohotkey():
    candidates = [
        r"C:\Program Files\AutoHotkey\AutoHotkey.exe",
        r"C:\Program Files (x86)\AutoHotkey\AutoHotkey.exe",
        r"C:\Program Files\AutoHotkey\v1\AutoHotkey.exe",
        r"C:\Program Files\AutoHotkey\AutoHotkeyU64.exe",
        r"C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe",
    ]
    for p in candidates:
        if os.path.isfile(p):
            return p
    return shutil.which("AutoHotkey") or shutil.which("AutoHotkeyU64")

def resource_path(relative_path):
    import sys
    base = getattr(sys, '_MEIPASS', os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, relative_path)
