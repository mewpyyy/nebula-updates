import tkinter as tk
from tkinter import font as tkfont

from config import resource_path
from scripts_loader import SERVER_SCRIPTS, script_count_for_server


class ServerSelect(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Nebula — Select Server")
        self.resizable(False, False)
        self.configure(bg="#0d0010")
        self._selected = None

        try:
            self.iconbitmap(resource_path("nebula.ico"))
        except Exception:
            pass

        font_title  = tkfont.Font(family="Segoe Script", size=18, weight="bold")
        font_sub    = tkfont.Font(family="Segoe UI",     size=9)
        font_server = tkfont.Font(family="Segoe UI",     size=13, weight="bold")
        font_desc   = tkfont.Font(family="Segoe UI",     size=8)

        wrap = tk.Frame(self, bg="#0d0010", padx=48, pady=36)
        wrap.pack()

        tk.Label(wrap, text="⬡ Nebula", font=font_title,
                 bg="#0d0010", fg="#c084fc").pack(pady=(0, 4))
        tk.Label(wrap, text="select your server", font=font_sub,
                 bg="#0d0010", fg="#6b21a8").pack(pady=(0, 28))

        # Script counts are derived from the remotely-loaded data
        prison_count   = script_count_for_server("Prison")
        skyblock_count = script_count_for_server("Skyblock")
        survival_count = script_count_for_server("Survival")

        servers = [
            ("Prison",   f"Select from {prison_count} scripts",                  "#4c1d95", "#c084fc"),
            ("Skyblock", f"Select from {skyblock_count} script{'s' if skyblock_count != 1 else ''}", "#1a1040", "#a855f7"),
            ("Survival", f"Select from {survival_count} scripts",                "#0d0820", "#6b21a8"),
        ]

        btn_frame = tk.Frame(wrap, bg="#0d0010")
        btn_frame.pack()

        for name, desc, bg_col, fg_col in servers:
            box = tk.Frame(btn_frame, bg=bg_col, cursor="hand2",
                           highlightbackground=fg_col, highlightthickness=1)
            box.pack(side="left", padx=10, ipadx=20, ipady=16)

            tk.Label(box, text=name, font=font_server,
                     bg=bg_col, fg=fg_col).pack(pady=(12, 4))
            tk.Label(box, text=desc, font=font_desc,
                     bg=bg_col, fg="#9d8cbb").pack(pady=(0, 12))

            box.bind("<Button-1>", lambda e, n=name: self._select(n))
            for child in box.winfo_children():
                child.bind("<Button-1>", lambda e, n=name: self._select(n))

            def on_enter(e, b=box):
                b.config(highlightthickness=2)
            def on_leave(e, b=box):
                b.config(highlightthickness=1)
            box.bind("<Enter>", on_enter)
            box.bind("<Leave>", on_leave)

        self.update_idletasks()
        w, h = self.winfo_width(), self.winfo_height()
        x = (self.winfo_screenwidth()  - w) // 2
        y = (self.winfo_screenheight() - h) // 2
        self.geometry(f"+{x}+{y}")

    def _select(self, server):
        self._selected = server
        self.destroy()
