"""
scripts_loader.py
Fetches the SCRIPTS list from GitHub at startup.
Each entry has: display_name, filename, description, servers, script.
Also builds the SERVER_SCRIPTS dict from the servers field.
"""

import json
import time
import urllib.request
import urllib.error

from config import SCRIPTS_JSON_URL

# Module-level cache populated by load_scripts()
SCRIPTS: list = []
SERVER_SCRIPTS: dict = {}   # {"Prison": None, "Skyblock": [...], ...}
_KNOWN_SERVERS: list = ["Prison", "Skyblock", "Survival"]


def load_scripts() -> bool:
    """
    Fetch scripts.json from GitHub and populate SCRIPTS / SERVER_SCRIPTS.
    Returns True on success, False on failure (SCRIPTS will be empty).
    """
    global SCRIPTS, SERVER_SCRIPTS
    try:
        url = f"{SCRIPTS_JSON_URL}?t={int(time.time())}"
        req = urllib.request.Request(
            url,
            headers={"Cache-Control": "no-cache", "User-Agent": "Nebula-Updater"}
        )
        resp = urllib.request.urlopen(req, timeout=10)
        data = json.loads(resp.read().decode("utf-8"))

        if not isinstance(data, list):
            return False

        SCRIPTS = data

        # Build SERVER_SCRIPTS from the servers field on each script.
        # A script with no "servers" key (or an empty list) is treated as
        # available on all servers (same behaviour as the old None sentinel).
        server_map: dict[str, list] = {}

        for script in SCRIPTS:
            servers = script.get("servers") or []
            if not servers:
                # Available everywhere — mark each known server as "all"
                for s in _KNOWN_SERVERS:
                    server_map.setdefault(s, None)   # None = show all
            else:
                for s in servers:
                    if s not in server_map:
                        server_map[s] = []
                    if server_map[s] is not None:
                        server_map[s].append(script["filename"])

        # Ensure every known server exists in the map
        for s in _KNOWN_SERVERS:
            if s not in server_map:
                server_map[s] = []   # no scripts for this server

        SERVER_SCRIPTS = server_map
        return True

    except Exception:
        return False


def get_scripts_for_server(server: str) -> list:
    """Return the filtered script list for a given server name."""
    allowed = SERVER_SCRIPTS.get(server)
    if allowed is None:
        return list(SCRIPTS)
    if len(allowed) == 0:
        return []
    return [s for s in SCRIPTS if s["filename"] in allowed]


def script_count_for_server(server: str) -> int:
    return len(get_scripts_for_server(server))
