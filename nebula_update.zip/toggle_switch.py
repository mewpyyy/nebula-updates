import tkinter as tk


class ToggleSwitch(tk.Frame):
    """3-position switch: STOPPED (left) → RUNNING (centre) → ACTIVE (right)
    Clicking cycles: off → on (running). AHK hotkeys update state via set_state().
    Positions: 0=STOPPED, 1=RUNNING, 2=ACTIVE
    """
    W, H, PAD = 78, 28, 3

    def __init__(self, parent, theme, callback=None, **kwargs):
        super().__init__(parent, bg=theme["card_bg"], cursor="hand2",
                         width=self.W, height=self.H, **kwargs)
        self.pack_propagate(False)
        self._pos      = 0
        self._callback = callback
        self._theme    = theme

        self._canvas = tk.Canvas(self, width=self.W, height=self.H,
                                  highlightthickness=0, bd=0,
                                  bg=theme["card_bg"])
        self._canvas.place(x=0, y=0)
        self._canvas.bind("<Button-1>", self._click)
        self._draw()

    # ── Drawing ───────────────────────────────────────────────────────────────
    def _track_color(self):
        if self._pos == 0:   return self._theme["tog_off"]
        elif self._pos == 1: return self._theme.get("tog_mid", "#a855f7")
        else:                return self._theme["tog_on"]

    def _knob_x(self):
        ks = self.H - self.PAD * 2
        if self._pos == 0:   return self.PAD
        elif self._pos == 1: return (self.W - ks) // 2
        else:                return self.W - ks - self.PAD

    def _draw(self):
        c = self._canvas
        c.delete("all")
        W, H, r = self.W, self.H, self.H // 2
        tc = self._track_color()
        c.create_arc(0, 0, H, H, start=90, extent=180, fill=tc, outline=tc)
        c.create_arc(W-H, 0, W, H, start=270, extent=180, fill=tc, outline=tc)
        c.create_rectangle(r, 0, W-r, H, fill=tc, outline=tc)
        ks = H - self.PAD * 2
        kx = self._knob_x()
        ky = self.PAD
        c.create_oval(kx, ky, kx+ks, ky+ks, fill="#ffffff", outline="#ffffff")

    # ── Public API ────────────────────────────────────────────────────────────
    def apply_theme(self, theme):
        self._theme = theme
        self._canvas.config(bg=theme["card_bg"])
        self._draw()

    def set_glow(self, active, color):
        if active and color:
            self._canvas.config(highlightthickness=1, highlightbackground=color)
        else:
            self._canvas.config(highlightthickness=0)

    def set_state(self, pos):
        if pos == self._pos:
            return
        self._animate_to(pos)

    def get_state(self):
        return self._pos

    # ── Animation ─────────────────────────────────────────────────────────────
    def _animate_to(self, target_pos, steps=4):
        start_x = self._knob_x()
        self._pos = target_pos
        end_x = self._knob_x()
        if start_x == end_x:
            self._draw()
            return
        step_size = (end_x - start_x) / steps
        self._anim_step(start_x, end_x, step_size, target_pos, 0, steps)

    def _anim_step(self, current_x, end_x, step_size, target_pos, step, steps):
        self._pos = target_pos
        c = self._canvas
        c.delete("all")
        W, H, r = self.W, self.H, self.H // 2
        tc = self._track_color()
        c.create_arc(0, 0, H, H, start=90, extent=180, fill=tc, outline=tc)
        c.create_arc(W-H, 0, W, H, start=270, extent=180, fill=tc, outline=tc)
        c.create_rectangle(r, 0, W-r, H, fill=tc, outline=tc)
        ks = H - self.PAD * 2
        kx = int(current_x + step_size * step)
        ky = self.PAD
        c.create_oval(kx, ky, kx+ks, ky+ks, fill="#ffffff", outline="#ffffff")
        if step < steps:
            self._canvas.after(20, lambda: self._anim_step(
                current_x, end_x, step_size, target_pos, step + 1, steps))
        else:
            self._draw()

    # ── Click handler ─────────────────────────────────────────────────────────
    def _click(self, _=None):
        if self._pos == 0:
            self._animate_to(1)
            if self._callback:
                self._callback(True)
        else:
            self._animate_to(0)
            if self._callback:
                self._callback(False)
