import tkinter as tk
from tkinter import font as tkfont, colorchooser

from config import PRESET_THEMES, save_theme


class ThemeEditor(tk.Toplevel):
    LABELS = {
        "bg":      "Background",
        "card_bg": "Card Background",
        "border":  "Border",
        "accent":  "Accent (title/toggle)",
        "accent2": "Accent 2 (warnings)",
        "text":    "Script Name Text",
        "subtext": "Filename Text",
        "running": "Running Status",
        "stopped": "Stopped Status",
        "tog_on":  "Toggle ON",
        "tog_off": "Toggle OFF",
    }

    def __init__(self, parent, theme, on_apply):
        super().__init__(parent)
        self.title("Theme Editor")
        self.resizable(False, False)
        self.grab_set()
        self._on_apply = on_apply
        self._current  = dict(theme)
        self._swatches = {}

        font_b = tkfont.Font(family="Consolas", size=9, weight="bold")
        font_n = tkfont.Font(family="Consolas", size=9)

        self.configure(bg=theme["bg"])

        tk.Label(self, text="THEME EDITOR",
                 font=tkfont.Font(family="Consolas", size=13, weight="bold"),
                 bg=theme["bg"], fg=theme["accent"], pady=14).pack()

        # Preset row
        preset_frame = tk.Frame(self, bg=theme["bg"], padx=20, pady=4)
        preset_frame.pack(fill="x")
        tk.Label(preset_frame, text="Preset:", font=font_b,
                 bg=theme["bg"], fg=theme["text"]).pack(side="left", padx=(0, 8))
        for name in PRESET_THEMES:
            btn = tk.Label(preset_frame, text=name, font=font_n,
                           bg=theme["card_bg"], fg=theme["accent"],
                           padx=8, pady=4, cursor="hand2", relief="flat",
                           highlightbackground=theme["border"],
                           highlightthickness=1)
            btn.pack(side="left", padx=3)
            btn.bind("<Button-1>", lambda e, n=name: self._load_preset(n))

        tk.Frame(self, bg=theme["border"], height=1).pack(fill="x", padx=20, pady=10)

        # Colour rows
        grid = tk.Frame(self, bg=theme["bg"], padx=20)
        grid.pack(fill="x")

        for row, (key, label) in enumerate(self.LABELS.items()):
            tk.Label(grid, text=label, font=font_n, bg=theme["bg"],
                     fg=theme["text"], anchor="w", width=22).grid(
                row=row, column=0, pady=4, sticky="w")

            swatch = tk.Label(grid, bg=theme[key], width=4,
                              relief="flat", cursor="hand2",
                              highlightbackground=theme["border"],
                              highlightthickness=1)
            swatch.grid(row=row, column=1, padx=(8, 6), pady=4)
            swatch.bind("<Button-1>", lambda e, k=key: self._pick(k))

            hex_var = tk.StringVar(value=theme[key])
            hex_entry = tk.Entry(grid, textvariable=hex_var, font=font_n,
                                 bg=theme["card_bg"], fg=theme["text"],
                                 insertbackground=theme["text"],
                                 relief="flat", width=9,
                                 highlightbackground=theme["border"],
                                 highlightthickness=1)
            hex_entry.grid(row=row, column=2, padx=4, pady=4)
            hex_var.trace_add("write", lambda *a, k=key, v=hex_var: self._hex_typed(k, v))

            self._swatches[key] = (swatch, hex_var)

        tk.Frame(self, bg=theme["border"], height=1).pack(fill="x", padx=20, pady=10)

        btn_row = tk.Frame(self, bg=theme["bg"], pady=12)
        btn_row.pack()

        def make_btn(text, cmd, fg):
            b = tk.Label(btn_row, text=text, font=font_b, bg=theme["card_bg"],
                         fg=fg, padx=16, pady=8, cursor="hand2", relief="flat",
                         highlightbackground=theme["border"], highlightthickness=1)
            b.pack(side="left", padx=8)
            b.bind("<Button-1>", lambda e: cmd())
            return b

        make_btn("Apply & Save", self._apply, theme["accent"])
        make_btn("Cancel",       self.destroy, theme["accent2"])

        self.update_idletasks()
        px = parent.winfo_x() + (parent.winfo_width()  - self.winfo_width())  // 2
        py = parent.winfo_y() + (parent.winfo_height() - self.winfo_height()) // 2
        self.geometry(f"+{px}+{py}")

    def _pick(self, key):
        result = colorchooser.askcolor(
            color=self._current[key], title=f"Pick colour — {self.LABELS[key]}")
        if result and result[1]:
            self._set_colour(key, result[1])

    def _hex_typed(self, key, var):
        val = var.get().strip()
        if len(val) == 7 and val.startswith("#"):
            try:
                int(val[1:], 16)
                self._current[key] = val
                self._swatches[key][0].config(bg=val)
            except ValueError:
                pass

    def _set_colour(self, key, hex_col):
        self._current[key] = hex_col
        swatch, hex_var = self._swatches[key]
        swatch.config(bg=hex_col)
        hex_var.set(hex_col)

    def _load_preset(self, name):
        preset = PRESET_THEMES[name]
        for key, val in preset.items():
            self._set_colour(key, val)

    def _apply(self):
        save_theme(self._current)
        self._on_apply(self._current)
        self.destroy()
