"""
updater.py
Auto-update logic: version check, download zip of all .py files, auto-restart.
"""

import os
import sys
import json
import shutil
import tempfile
import zipfile
import urllib.request
import urllib.error
import tkinter as tk
from tkinter import messagebox

from config import (
    CURRENT_VERSION, UPDATE_VERSION_URL, UPDATE_ZIP_URL,
    PATCH_NOTES_URL, PATCH_NOTES,
)

UPDATE_FILES = [
    "main.py", "config.py", "scripts_loader.py", "ahk_manager.py",
    "toggle_switch.py", "theme_editor.py", "login_screen.py",
    "server_select.py", "updater.py",
]


def check_for_update(callback):
    try:
        import time
        url = f"{UPDATE_VERSION_URL}?t={int(time.time())}"
        req = urllib.request.Request(
            url, headers={"Cache-Control": "no-cache", "User-Agent": "Nebula-Updater"})
        resp = urllib.request.urlopen(req, timeout=5)
        data = json.loads(resp.read().decode())
        latest = data.get("version", "")
        if latest and latest != CURRENT_VERSION:
            callback(latest)
    except Exception:
        pass


def fetch_patch_notes(version: str) -> list:
    try:
        import time
        url = f"{PATCH_NOTES_URL}?t={int(time.time())}"
        req = urllib.request.Request(
            url, headers={"Cache-Control": "no-cache", "User-Agent": "Nebula-Updater"})
        resp = urllib.request.urlopen(req, timeout=5)
        data = json.loads(resp.read().decode())
        return data.get(version, [])
    except Exception:
        return PATCH_NOTES.get(version, [])


def download_and_restart(parent_window, procs: dict, tmp_dir: str):
    try:
        is_frozen = getattr(sys, "frozen", False)
        exe_dir = os.path.dirname(os.path.abspath(sys.executable if is_frozen else sys.argv[0]))

        # Clean up leftover temp zips
        tmp = tempfile.gettempdir()
        for f in os.listdir(tmp):
            if f.startswith("nebula_update_"):
                try: os.remove(os.path.join(tmp, f))
                except Exception: pass

        # Download zip
        import uuid, time
        zip_tmp = os.path.join(tmp, f"nebula_update_{uuid.uuid4().hex}.zip")
        url = f"{UPDATE_ZIP_URL}?t={int(time.time())}"
        req = urllib.request.Request(
            url, headers={"Cache-Control": "no-cache", "User-Agent": "Nebula-Updater"})
        with urllib.request.urlopen(req, timeout=30) as resp:
            zip_bytes = resp.read()
        with open(zip_tmp, "wb") as f:
            f.write(zip_bytes)

        # Validate and extract
        with zipfile.ZipFile(zip_tmp, "r") as zf:
            names = zf.namelist()
            if not any("ahk_manager.py" in n for n in names):
                raise ValueError("Downloaded zip doesn't look like a Nebula update.")
            for member in zf.infolist():
                basename = os.path.basename(member.filename)
                if basename in UPDATE_FILES:
                    dest = os.path.join(exe_dir, basename)
                    if os.path.exists(dest):
                        shutil.copy2(dest, dest + ".bak")
                    member.filename = basename
                    zf.extract(member, exe_dir)

        os.remove(zip_tmp)

        # Stop all scripts
        for proc in procs.values():
            try: proc.terminate()
            except Exception: pass
        shutil.rmtree(tmp_dir, ignore_errors=True)

        # Auto-restart
        parent_window.destroy()
        os.execv(sys.executable, [sys.executable] + sys.argv)

    except Exception as ex:
        messagebox.showerror(
            "Update Failed",
            f"Could not update Nebula:\n\n{ex}\n\nYour current version is unchanged.")


def show_update_prompt(parent, latest_version: str,
                       procs: dict, tmp_dir: str,
                       font_name, font_file, font_status, font_badge, theme: dict):
    t = theme
    win = tk.Toplevel(parent)
    win.title("Update Available")
    win.resizable(False, False)
    win.configure(bg=t["bg"])
    win.grab_set()

    tk.Label(win, text="Update Available", bg=t["bg"], fg=t["accent"],
             font=font_name, pady=14).pack()
    tk.Frame(win, bg=t["border"], height=1).pack(fill="x", padx=20)

    frame = tk.Frame(win, bg=t["bg"], padx=30, pady=16)
    frame.pack()
    tk.Label(frame, text=f"Current version:  {CURRENT_VERSION}",
             font=font_file, bg=t["bg"], fg=t["subtext"]).pack(anchor="w")
    tk.Label(frame, text=f"New version:       {latest_version}",
             font=font_file, bg=t["bg"], fg=t["running"]).pack(anchor="w", pady=(4, 0))

    notes = fetch_patch_notes(latest_version)
    if notes:
        tk.Frame(frame, bg=t["border"], height=1).pack(fill="x", pady=(12, 8))
        tk.Label(frame, text=f"What's new in v{latest_version}:",
                 font=font_status, bg=t["bg"], fg=t["accent"]).pack(anchor="w")
        for note in notes:
            tk.Label(frame, text=f"  • {note}", font=font_file,
                     bg=t["bg"], fg=t["text"], wraplength=340,
                     justify="left", anchor="w").pack(anchor="w", pady=1)

    tk.Label(frame, text="\nWould you like to update now?",
             font=font_file, bg=t["bg"], fg=t["text"]).pack()

    tk.Frame(win, bg=t["border"], height=1).pack(fill="x", padx=20)
    btn_row = tk.Frame(win, bg=t["bg"], pady=12)
    btn_row.pack()

    def do_update():
        win.destroy()
        download_and_restart(parent, procs, tmp_dir)

    for text, cmd, col in [("Update Now", do_update, t["accent"]),
                            ("Later",      win.destroy, t["accent2"])]:
        b = tk.Label(btn_row, text=text, font=font_badge,
                     bg=t["card_bg"], fg=col, padx=16, pady=8,
                     cursor="hand2", highlightbackground=t["border"], highlightthickness=1)
        b.pack(side="left", padx=8)
        b.bind("<Button-1>", lambda e, c=cmd: c())

    win.update_idletasks()
    px = parent.winfo_x() + (parent.winfo_width()  - win.winfo_width())  // 2
    py = parent.winfo_y() + (parent.winfo_height() - win.winfo_height()) // 2
    win.geometry(f"+{px}+{py}")
