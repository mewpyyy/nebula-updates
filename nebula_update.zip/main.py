"""
main.py — Nebula entry point
Startup order:
  1. Fetch scripts.json from GitHub (populates SCRIPTS + SERVER_SCRIPTS)
  2. Login screen
  3. Server select screen
  4. Main AHKManager window
"""

import os
import sys

from config import validate_user_remote, load_session, save_session, clear_session, save_last_server, load_last_server
from scripts_loader import load_scripts, SERVER_SCRIPTS
from login_screen import LoginScreen
from server_select import ServerSelect
from ahk_manager import AHKManager


def _bootstrap_scripts():
    """
    Load scripts from GitHub before any window opens.
    If the fetch fails, the app still runs — script cards will simply be empty
    and an error label is shown on the server select screen.
    """
    success = load_scripts()
    if not success:
        print("[Nebula] Warning: could not fetch scripts.json — "
              "check your internet connection.")
    return success


def main():
    # ── onedir frozen mode: execute updated ahk_manager.py if present ─────────
    if getattr(sys, "frozen", False) and not os.environ.get("NEBULA_UPDATED"):
        exe_dir    = os.path.dirname(os.path.abspath(sys.executable))
        updated_py = os.path.join(exe_dir, "ahk_manager.py")
        if os.path.exists(updated_py):
            os.environ["NEBULA_UPDATED"] = "1"
            with open(updated_py, "r", encoding="utf-8") as f:
                code = f.read()
            exec(compile(code, updated_py, "exec"),
                 {"__name__": "__main__", "__file__": updated_py})
            sys.exit(0)

    # ── Fetch remote scripts before opening any window ────────────────────────
    _bootstrap_scripts()

    while True:
        # ── Login ─────────────────────────────────────────────────────────────
        session    = load_session()
        auto_login = (
            session and
            validate_user_remote(session.get("user", ""), session.get("pw", ""))
        )
        if auto_login:
            current_user = session["user"]
        else:
            login = LoginScreen()
            login.mainloop()
            if not login._success:
                break
            current_user = getattr(login, "_logged_user", "")

        # ── Server select ──────────────────────────────────────────────────────
        last_server = load_last_server()
        if last_server and last_server in SERVER_SCRIPTS:
            selected_server = last_server
        else:
            server_screen = ServerSelect()
            server_screen.mainloop()
            if not server_screen._selected:
                break
            selected_server = server_screen._selected
            save_last_server(selected_server)

        # ── Main window loop ───────────────────────────────────────────────────
        while True:
            app = AHKManager(
                current_user=current_user,
                server=selected_server,
                allowed_scripts=SERVER_SCRIPTS.get(selected_server),
            )
            app._logged_out              = False
            app._change_server_requested = False
            app.mainloop()

            if getattr(app, "_logged_out", False):
                save_last_server(None)
                break

            if getattr(app, "_change_server_requested", False):
                server_screen = ServerSelect()
                server_screen.mainloop()
                if not server_screen._selected:
                    break
                selected_server = server_screen._selected
                save_last_server(selected_server)
                continue

            break
        else:
            continue
        break


if __name__ == "__main__":
    main()
